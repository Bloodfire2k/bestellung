import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Optimierungen für Production
  experimental: {
    optimizeCss: true,
  },
  
  // Output-Konfiguration
  output: 'standalone',
  
  // Komprimierung aktivieren
  compress: true,
  
  // PWA-Einstellungen für mobile App
  headers: async () => {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ];
  },
  
  // Bild-Optimierung
  images: {
    formats: ['image/webp', 'image/avif'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
  },
};

export default nextConfig;
