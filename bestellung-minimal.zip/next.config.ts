import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Minimal config für Server mit wenig Memory
  output: 'standalone',
  compress: true,
  
  // Reduzierte Optimierungen
  images: {
    unoptimized: true, // Für Server mit wenig Memory
  },
  
  // Keine experimentellen Features
  swcMinify: true,
};

export default nextConfig;
